package Simulation;

public enum ProductType {
	GPU,Normal;
}
