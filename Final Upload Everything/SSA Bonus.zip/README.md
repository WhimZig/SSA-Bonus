SSA Bonus
